#!/usr/bin/env python
import sys
fid=open(sys.argv[2],'wr+')
for line in open(sys.argv[1]):
    line=line[:-1]
    if line[:2]=='##':
        fid.write(line + '\n')
        continue
    elif line[0]=='#':
        fid.write(line + '\t' + 'DP4' + '\t' + 'VAF\n')
        continue
    line1=line.split('\t')
    N_line1=line1[9].split(':')
    N_DP4=[int(element) for element in N_line1[-1].split(',')]
    if sum(N_DP4[2:])<1 and line1[6]=='PASS':
        T_line1=line1[10].split(':')
        DP4=T_line1[-1]
        T_DP4=[int(element) for element in DP4.split(',')]
        VAF=sum(T_DP4[2:])/float(sum(T_DP4))
        fid.write(line +'\t' + DP4 + '\t' + format(VAF,'.4f') + '\n')
fid.close()
