#!/usr/bin/env python
import sys

input_file=sys.argv[1]
somatic_out = sys.argv[2]
germline_out = sys.argv[3]
somatic=open(somatic_out,'wr+')
germline=open(germline_out,'wr+')
Chr=range(24)
for i in range(22):
    Chr[i]='chr'+str(i)
Chr[22]='chrX'
Chr[23]='chrY'
for line in open(input_file):
    if line[0]=='#':
        somatic.write(line)
        germline.write(line)
        continue
    if line.find('\x00')!=-1:
        continue
    line1=line.split('\t')
    if Chr.count(line1[0])!=1:
        continue
    line2=line1[7]
    line3=line1[10].split(':')
    vaf=float(line3[5][:-1])
    if line2.find('SOMATIC')!=-1:
        somatic.write(line)        
    elif line2.find('SS=1')!=-1 and vaf<90:
        germline.write(line)
somatic.close()
germline.close()
