#!/usr/bin/python
def ref_pos(a,len_a):
    t=0
    c=range(len_a)
    flag=0
    start=0
    flag1=0
    for i in range(len(a)):
            if ord(a[i])>58:
               b=int(a[t:i])
               t=i+1
               if a[i]=='S':
                  c[start:b+start]=[-1 for i in range(b)]
                  flag1=flag1-b
               elif a[i]=='I':
                   c[start:b+start]=[-1 for i in range(b)]
                   flag=flag-b
               elif a[i]=='D':
                  flag=flag+b
                  start=start-b
               elif a[i]=='M':
                  c[start:start+b]=[element+start+flag+flag1 for element in range(b)]
               start=start+b
    return c
