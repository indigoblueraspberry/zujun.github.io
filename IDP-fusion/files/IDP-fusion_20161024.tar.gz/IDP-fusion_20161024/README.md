IDP-fusion
===

IDP-fusion is an gene Isoform Detection and Prediction tool from Second Generation Sequencing and PacBio sequencing developed by Kin Fai Au. It offers very reliable gene isoform identification with high sensitivity. IDP-fusion can idetify and quantify fusion transcripts.

This version is IDP-fusion_20161024
